# Promptbook brand kit

Updated: 2026-11-05. Contact: pavol@ptbk.io.

Name: Promptbook. Visual wordmark: promptbook (no trailing dot).
Official abbreviation: ptbk (lowercase). CLI command: ptbk.
Use the supplied SVG/PNG assets. The PB mark projects onto a regular hexagon:
six equal sides, 120° interior angles. Never stretch, rotate, recolor or add effects.
Light artwork is transparent for white surfaces. Use the transparent white artwork on
ink blue #17386C or the all-white lockup with its solid black #000000 background.
Keep at least 1/4 of
the symbol's height clear on all sides. Minimum digital widths: symbol 32 px,
complete lockup 160 px. Headings: Outfit. Body: Inter.
Full wordmark: Inter Medium (500) for prompt, Inter Bold (700) for book, at equal sizes.
The abbreviated ptbk wordmark is entirely Inter Medium (500).
In the complete lockup, the cube's vertical edge matches the wordmark's cap height.
Logo SVGs contain vector paths, with no embedded bitmap or font dependency.
Editable slide/social templates require Outfit and Inter; their PNG exports do not.

## Czech

Promptbook předává dlouhodobé agendy AI agentům, kteří pracují na Vašem počítači nebo serveru podle Vašich pravidel.

Předáte agendu. Nastavíte pravidla. Spustíte agenty. Pracují sami. Ozvou se, jen když Vás potřebují. Vy máte kdykoliv přehled. Engine běží na Vašem počítači nebo serveru, s Vašimi soubory a modely, které si zvolíte.

## English

Promptbook hands ongoing work to AI agents that run on your computer or server and follow your rules.

Hand over a responsibility. Set the rules. Start your agents. They work independently. They ask only when they need you. You can check in at any time. The engine runs on your computer or server, with your files and your choice of models.

## Scope and sources

Applies only to Promptbook, not AI ta Krajta or Pavol Hejny personal sites.
Product copy: ptbk.io/cs, ptbk.io/en and webgptorg/promptbook reborn/2026-10 README.
Original PB curves: webgptorg/promptbook, reborn/2026-10, design/source/logo-design-system.svg; face projection corrected to exact regular geometry.
Work examples describe configured agents and permissions, not guaranteed outcomes.
Screenshots must be genuine current captures. Do not fabricate customer evidence.
